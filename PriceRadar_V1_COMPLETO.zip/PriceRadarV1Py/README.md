# PriceRadar V1

Aplicativo Android nativo em Java para comparação regional de preços.

Inclui splash animada, GPS, mapa, Mercado/Farmácia/Pet, busca por nome/EAN, scanner, estatísticas,
histórico local, favoritos e motores modulares.

## Fontes beta integradas
- Savegnago (Mercado)
- Drogasil (Farmácia)
- Petz (Pet)

Fontes que falham ou não retornam produto válido são ocultadas.

## Build no Codespaces
```bash
chmod +x build_in_codespaces.sh
./build_in_codespaces.sh
```

APK: `app/build/outputs/apk/debug/app-debug.apk`
