#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"
echo "== PriceRadar V1 =="
gradle testDebugUnitTest --stacktrace
gradle assembleDebug --stacktrace
echo "APK:"
ls -lh app/build/outputs/apk/debug/app-debug.apk
