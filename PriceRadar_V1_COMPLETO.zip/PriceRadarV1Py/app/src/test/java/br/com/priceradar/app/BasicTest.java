package br.com.priceradar.app;
import org.junit.Test; import static org.junit.Assert.*;
public class BasicTest { @Test public void math(){ assertEquals(10.0,(8.0+10.0+12.0)/3.0,0.001); } }
