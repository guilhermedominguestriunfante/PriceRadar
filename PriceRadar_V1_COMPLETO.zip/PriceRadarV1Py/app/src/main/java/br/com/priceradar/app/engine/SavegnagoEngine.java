package br.com.priceradar.app.engine;
import android.net.Uri;
import br.com.priceradar.app.model.PriceResult;
import java.util.*; import java.util.regex.*;
import org.jsoup.Jsoup; import org.jsoup.nodes.*;
public final class SavegnagoEngine extends BaseHtmlEngine {
    public String id(){return "Savegnago";} public PriceResult.Category category(){return PriceResult.Category.MARKET;}
    public List<PriceResult> search(String q,double lat,double lon)throws Exception{
        String url="https://www.savegnago.com.br/busca?q="+Uri.encode(q),html=get(url);
        Document doc=Jsoup.parse(html,url); List<PriceResult> out=new ArrayList<>();
        for(Element a:doc.select("a[href*='/p']")){
            if(out.size()>=8)break;
            String title=a.text().trim(), block=a.parent()!=null?a.parent().text():title;
            Matcher pm=Pattern.compile("R\\$\\s*([0-9]{1,4}(?:\\.[0-9]{3})*,[0-9]{2})").matcher(block);
            if(!pm.find())continue;
            double c=TextTools.confidence(q,title);
            if(c<.45&&!TextTools.isEan(q))continue;
            double price=Double.parseDouble(pm.group(1).replace(".","").replace(",","."));
            out.add(new PriceResult("Savegnago",title,"",price,a.absUrl("href"),c));
        }
        return out;
    }
}
