package br.com.priceradar.app.model;
public final class PriceResult {
    public enum Category { MARKET, PHARMACY, PET }
    public final String source, productName, ean, url;
    public final double price, confidence;
    public PriceResult(String s,String n,String e,double p,String u,double c){
        source=s;productName=n;ean=e;price=p;url=u;confidence=c;
    }
}
