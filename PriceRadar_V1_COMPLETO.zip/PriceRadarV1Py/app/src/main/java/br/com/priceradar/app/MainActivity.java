package br.com.priceradar.app;
import android.Manifest; import android.content.*; import android.content.pm.PackageManager; import android.location.Location; import android.os.Bundle; import android.widget.*;
import androidx.annotation.NonNull; import androidx.appcompat.app.*; import androidx.core.app.ActivityCompat;
import br.com.priceradar.app.data.LocalStore; import br.com.priceradar.app.model.PriceResult;
import com.google.android.gms.location.*; import com.google.android.gms.mlkit_code_scanner.*;
import org.osmdroid.config.Configuration; import org.osmdroid.tileprovider.tilesource.TileSourceFactory; import org.osmdroid.util.GeoPoint; import org.osmdroid.views.MapView; import org.osmdroid.views.overlay.Marker;
import java.util.*;
public final class MainActivity extends AppCompatActivity {
    private static final int REQ=42; private double lat=-22.9056,lon=-47.0608; private PriceResult.Category cat=PriceResult.Category.MARKET;
    private MapView map; private EditText input; private TextView loc,status; private FusedLocationProviderClient gps; private LocalStore local;
    protected void onCreate(Bundle b){super.onCreate(b);Configuration.getInstance().setUserAgentValue(getPackageName());setContentView(R.layout.activity_main);
        local=new LocalStore(this);map=findViewById(R.id.map);input=findViewById(R.id.searchInput);loc=findViewById(R.id.locationText);status=findViewById(R.id.categoryStatus);
        map.setTileSource(TileSourceFactory.MAPNIK);map.setMultiTouchControls(true);map.getController().setZoom(13.5);map.getController().setCenter(new GeoPoint(lat,lon));
        findViewById(R.id.btnMarket).setOnClickListener(v->choose(PriceResult.Category.MARKET,"Mercado"));
        findViewById(R.id.btnPharmacy).setOnClickListener(v->choose(PriceResult.Category.PHARMACY,"Farmácia"));
        findViewById(R.id.btnPet).setOnClickListener(v->choose(PriceResult.Category.PET,"Pet"));
        findViewById(R.id.btnScan).setOnClickListener(v->scan());findViewById(R.id.btnSearch).setOnClickListener(v->search());
        findViewById(R.id.btnHistory).setOnClickListener(v->list("Histórico",local.history()));findViewById(R.id.btnFavorites).setOnClickListener(v->list("Favoritos",local.favorites()));
        findViewById(R.id.btnSettings).setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        gps=LocationServices.getFusedLocationProviderClient(this);requestLocation();}
    private void choose(PriceResult.Category c,String s){cat=c;status.setText(s+" • raio 10 km");}
    private void scan(){GmsBarcodeScanning.getClient(this).startScan().addOnSuccessListener(x->{if(x.getRawValue()!=null){input.setText(x.getRawValue());search();}});}
    private void search(){String q=input.getText().toString().trim();if(q.isEmpty()){Toast.makeText(this,"Digite ou escaneie um produto.",Toast.LENGTH_SHORT).show();return;}local.addHistory(q);
        Intent i=new Intent(this,ResultActivity.class);i.putExtra("query",q);i.putExtra("category",cat.name());i.putExtra("lat",lat);i.putExtra("lon",lon);startActivity(i);}
    private void requestLocation(){if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ);return;}gps.getLastLocation().addOnSuccessListener(this::show);}
    private void show(Location l){if(l!=null){lat=l.getLatitude();lon=l.getLongitude();}GeoPoint p=new GeoPoint(lat,lon);map.getController().animateTo(p);map.getOverlays().clear();Marker m=new Marker(map);m.setPosition(p);m.setTitle("Você está aqui");map.getOverlays().add(m);map.invalidate();loc.setText(l==null?"Campinas • região inicial":String.format(Locale.getDefault(),"Sua região • %.4f, %.4f",lat,lon));}
    public void onRequestPermissionsResult(int r,@NonNull String[]p,@NonNull int[]g){super.onRequestPermissionsResult(r,p,g);if(r==REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)requestLocation();else if(r==REQ)show(null);}
    private void list(String title,List<String> items){String text=items.isEmpty()?"Nenhum item salvo ainda.":String.join("\n\n",items);new AlertDialog.Builder(this).setTitle(title).setMessage(text).setPositiveButton("Fechar",null).show();}
    protected void onResume(){super.onResume();map.onResume();}protected void onPause(){map.onPause();super.onPause();}
}
