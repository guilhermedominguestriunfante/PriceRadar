package br.com.priceradar.app.engine;
import android.net.Uri;
import br.com.priceradar.app.model.PriceResult;
import java.util.*; import java.util.regex.*;
import org.jsoup.Jsoup; import org.jsoup.nodes.*;
public final class DrogasilEngine extends BaseHtmlEngine {
    public String id(){return "Drogasil";} public PriceResult.Category category(){return PriceResult.Category.PHARMACY;}
    public List<PriceResult> search(String q,double lat,double lon)throws Exception{
        String[] urls={"https://www.drogasil.com.br/search?w="+Uri.encode(q),"https://www.drogasil.com.br/?origin=search&q="+Uri.encode(q)};
        for(String url:urls){try{List<PriceResult> r=parse(url,q,get(url));if(!r.isEmpty())return r;}catch(Exception ignored){}}
        return Collections.emptyList();
    }
    private List<PriceResult> parse(String url,String q,String html){
        List<PriceResult> out=new ArrayList<>(); Document doc=Jsoup.parse(html,url);
        for(Element a:doc.select("a[href*='.html']")){
            if(out.size()>=8)break;
            String title=a.text().trim(),block=a.parent()!=null?a.parent().text():title;
            Matcher pm=Pattern.compile("R\\$\\s*([0-9]{1,4}(?:\\.[0-9]{3})*,[0-9]{2})").matcher(block);
            if(!pm.find())continue;
            double c=TextTools.confidence(q,title); if(c<.45&&!TextTools.isEan(q))continue;
            double price=Double.parseDouble(pm.group(1).replace(".","").replace(",","."));
            out.add(new PriceResult("Drogasil",title,TextTools.isEan(q)?q:"",price,a.absUrl("href"),c));
        }
        return out;
    }
}
