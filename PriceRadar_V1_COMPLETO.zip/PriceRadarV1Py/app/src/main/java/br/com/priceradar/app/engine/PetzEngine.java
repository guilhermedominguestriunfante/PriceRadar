package br.com.priceradar.app.engine;
import android.net.Uri;
import br.com.priceradar.app.model.PriceResult;
import java.util.*; import java.util.regex.*;
public final class PetzEngine extends BaseHtmlEngine {
    public String id(){return "Petz";} public PriceResult.Category category(){return PriceResult.Category.PET;}
    public List<PriceResult> search(String q,double lat,double lon)throws Exception{
        String url="https://www.petz.com.br/busca?q="+Uri.encode(q), html=get(url);
        List<PriceResult> out=new ArrayList<>();
        Pattern p=Pattern.compile("\\{\\\"price\\\":\\\"([0-9.]+)\\\",\\\"name\\\":\\\"([^\\\"]+)\\\"(?:,\\\"promotional_price\\\":\\\"([0-9.]+)\\\")?.*?\\\"sku\\\":\\\"([^\\\"]+)\\\"",Pattern.DOTALL);
        Matcher m=p.matcher(html);
        while(m.find()&&out.size()<8){
            double regular=Double.parseDouble(m.group(1)), promo=m.group(3)!=null?Double.parseDouble(m.group(3)):regular;
            String name=m.group(2); double c=TextTools.confidence(q,name);
            if(TextTools.isEan(q))c=Math.max(c,.70);
            if(c>=.45&&promo>0)out.add(new PriceResult("Petz",name,"",promo,url,c));
        }
        return out;
    }
}
