package br.com.priceradar.app;
import android.animation.*; import android.content.*; import android.os.*; import android.view.*; import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
public final class SplashActivity extends AppCompatActivity {
    protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_splash);TextView r=findViewById(R.id.radarIcon);
        ObjectAnimator a=ObjectAnimator.ofFloat(r,View.ROTATION,0,360);a.setDuration(1700);a.setRepeatCount(ValueAnimator.INFINITE);a.start();
        new Handler(Looper.getMainLooper()).postDelayed(()->{startActivity(new Intent(this,MainActivity.class));finish();},2200);}
}
