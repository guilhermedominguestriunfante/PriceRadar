package br.com.priceradar.app.engine;
import java.text.Normalizer;
import java.util.Locale;
public final class TextTools {
    public static String normalize(String s){
        if(s==null)return "";
        return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","")
            .toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]"," ").replaceAll("\\s+"," ").trim();
    }
    public static double confidence(String q,String t){
        q=normalize(q);t=normalize(t); if(q.isEmpty()||t.isEmpty())return 0;
        if(t.contains(q))return .98;
        String[] ps=q.split(" "); int h=0; for(String p:ps)if(p.length()>1&&t.contains(p))h++;
        return Math.min(.96,(double)h/Math.max(1,ps.length));
    }
    public static boolean isEan(String q){return q!=null&&q.matches("\\d{8}|\\d{12,14}");}
}
