package br.com.priceradar.app.data;
import android.content.*; import java.util.*;
public final class LocalStore {
    private final SharedPreferences p;
    public LocalStore(Context c){p=c.getSharedPreferences("priceradar_local",Context.MODE_PRIVATE);}
    public void addHistory(String q){if(q==null||q.isBlank())return;Set<String>s=new LinkedHashSet<>(p.getStringSet("history",new LinkedHashSet<>()));s.add(q);p.edit().putStringSet("history",s).apply();}
    public List<String> history(){return new ArrayList<>(p.getStringSet("history",new LinkedHashSet<>()));}
    public void toggleFavorite(String q){Set<String>s=new LinkedHashSet<>(p.getStringSet("favorites",new LinkedHashSet<>()));if(!s.remove(q))s.add(q);p.edit().putStringSet("favorites",s).apply();}
    public boolean isFavorite(String q){return p.getStringSet("favorites",new LinkedHashSet<>()).contains(q);}
    public List<String> favorites(){return new ArrayList<>(p.getStringSet("favorites",new LinkedHashSet<>()));}
}
