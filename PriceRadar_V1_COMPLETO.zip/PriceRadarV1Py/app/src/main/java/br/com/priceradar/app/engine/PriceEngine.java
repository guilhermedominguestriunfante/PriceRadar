package br.com.priceradar.app.engine;
import br.com.priceradar.app.model.PriceResult;
import java.util.List;
public interface PriceEngine {
    String id();
    PriceResult.Category category();
    List<PriceResult> search(String query,double lat,double lon) throws Exception;
}
