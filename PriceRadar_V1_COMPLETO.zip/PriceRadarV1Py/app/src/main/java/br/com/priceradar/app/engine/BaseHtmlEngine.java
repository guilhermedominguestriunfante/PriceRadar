package br.com.priceradar.app.engine;
import java.util.concurrent.TimeUnit;
import okhttp3.*;
public abstract class BaseHtmlEngine implements PriceEngine {
    protected final OkHttpClient client=new OkHttpClient.Builder().connectTimeout(8,TimeUnit.SECONDS)
        .readTimeout(12,TimeUnit.SECONDS).callTimeout(15,TimeUnit.SECONDS).build();
    protected String get(String url)throws Exception{
        Request r=new Request.Builder().url(url)
            .header("User-Agent","Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            .header("Accept-Language","pt-BR,pt;q=0.9").build();
        try(Response x=client.newCall(r).execute()){
            if(!x.isSuccessful()||x.body()==null)throw new IllegalStateException("HTTP "+x.code());
            return x.body().string();
        }
    }
}
