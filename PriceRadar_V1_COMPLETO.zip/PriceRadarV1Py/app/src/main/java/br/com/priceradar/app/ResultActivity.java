package br.com.priceradar.app;
import android.content.*; import android.net.Uri; import android.os.Bundle; import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import br.com.priceradar.app.data.LocalStore; import br.com.priceradar.app.engine.EngineCoordinator; import br.com.priceradar.app.model.PriceResult;
import java.util.*;
public final class ResultActivity extends AppCompatActivity {
    private String q; private PriceResult.Category cat; private double lat,lon; private LinearLayout box; private TextView stats,count; private LocalStore local; private Button fav;
    protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_result);q=getIntent().getStringExtra("query");cat=PriceResult.Category.valueOf(getIntent().getStringExtra("category"));lat=getIntent().getDoubleExtra("lat",-22.9056);lon=getIntent().getDoubleExtra("lon",-47.0608);local=new LocalStore(this);
        ((TextView)findViewById(R.id.productName)).setText(q);((TextView)findViewById(R.id.productMeta)).setText("Consulta ao vivo • região atual");stats=findViewById(R.id.statistics);count=findViewById(R.id.resultCount);box=findViewById(R.id.resultsContainer);fav=findViewById(R.id.btnFavorite);syncFav();
        findViewById(R.id.btnBack).setOnClickListener(v->finish());findViewById(R.id.btnNewSearch).setOnClickListener(v->finish());fav.setOnClickListener(v->{local.toggleFavorite(q);syncFav();});stats.setText("Consultando fontes...");
        new Thread(()->{List<PriceResult>r=new EngineCoordinator().search(cat,q,lat,lon);runOnUiThread(()->render(r));}).start();}
    private void syncFav(){fav.setText(local.isFavorite(q)?"♥ Remover dos favoritos":"♡ Adicionar aos favoritos");}
    private void render(List<PriceResult> r){box.removeAllViews();if(r.isEmpty()){stats.setText("Nenhum preço válido encontrado.");count.setText("Tente outra descrição ou EAN.");return;}
        List<Double>p=new ArrayList<>();for(PriceResult x:r)p.add(x.price);Collections.sort(p);double sum=0;for(double x:p)sum+=x;double med=p.size()%2==1?p.get(p.size()/2):(p.get(p.size()/2-1)+p.get(p.size()/2))/2;
        stats.setText(String.format(Locale.forLanguageTag("pt-BR"),"MENOR  R$ %.2f\nMÉDIA  R$ %.2f\nMEDIANA  R$ %.2f\nMAIOR  R$ %.2f",p.get(0),sum/p.size(),med,p.get(p.size()-1)).replace('.',','));count.setText(r.size()+" preço(s) encontrado(s)");
        for(PriceResult x:r){Button b=new Button(this);b.setAllCaps(false);b.setText(String.format(Locale.forLanguageTag("pt-BR"),"%s  •  R$ %.2f\n%s\nMatch %d%%",x.source,x.price,x.productName,Math.round(x.confidence*100)).replace('.',','));b.setOnClickListener(v->{if(x.url!=null&&!x.url.isBlank())startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(x.url)));});box.addView(b);}}
}
