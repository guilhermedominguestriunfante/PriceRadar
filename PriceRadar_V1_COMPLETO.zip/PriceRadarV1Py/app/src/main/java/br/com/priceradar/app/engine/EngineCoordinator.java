package br.com.priceradar.app.engine;
import br.com.priceradar.app.model.PriceResult;
import java.util.*; import java.util.concurrent.*;
public final class EngineCoordinator {
    private final List<PriceEngine> engines=Arrays.asList(new SavegnagoEngine(),new DrogasilEngine(),new PetzEngine());
    public List<PriceResult> search(PriceResult.Category cat,String q,double lat,double lon){
        ExecutorService pool=Executors.newFixedThreadPool(3); List<Future<List<PriceResult>>> fs=new ArrayList<>();
        for(PriceEngine e:engines)if(e.category()==cat)fs.add(pool.submit(()->e.search(q,lat,lon)));
        List<PriceResult> out=new ArrayList<>();
        for(Future<List<PriceResult>> f:fs)try{List<PriceResult> r=f.get(16,TimeUnit.SECONDS);if(r!=null)out.addAll(r);}catch(Exception ignored){}
        pool.shutdownNow(); out.removeIf(r->r.price<=0||r.productName==null||r.productName.isBlank());
        out.sort(Comparator.comparingDouble(r->r.price)); return out;
    }
}
