package br.com.priceradar.app;
import android.os.Bundle; import androidx.appcompat.app.AppCompatActivity;
public final class SettingsActivity extends AppCompatActivity {
    protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings);findViewById(R.id.btnBack).setOnClickListener(v->finish());}
}
